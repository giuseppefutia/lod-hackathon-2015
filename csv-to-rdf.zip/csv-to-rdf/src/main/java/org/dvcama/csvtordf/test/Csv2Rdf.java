package org.dvcama.csvtordf.test;

public class Csv2Rdf {

}
